//
//  AIRGMSPolyline.m
//  AirMaps
//
//  Created by Guilherme Pontes 04/05/2017.
//

#ifdef HAVE_GOOGLE_MAPS

#import "AIRGMSPolyline.h"

@implementation AIRGMSPolyline
@end

#endif
