//
//  AIRGoogleMapPolylineManager.h
//
//  Created by Nick Italiano on 10/22/16.
//

#ifdef HAVE_GOOGLE_MAPS

#import <React/RCTViewManager.h>

@interface AIRGoogleMapPolylineManager : RCTViewManager

@end

#endif
