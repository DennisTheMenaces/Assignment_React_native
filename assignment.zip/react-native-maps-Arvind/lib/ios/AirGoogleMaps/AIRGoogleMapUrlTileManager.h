//
//  AIRGoogleMapURLTileManager.h
//  Created by Nick Italiano on 11/5/16.
//

#ifdef HAVE_GOOGLE_MAPS

#import <Foundation/Foundation.h>
#import <React/RCTViewManager.h>

@interface AIRGoogleMapUrlTileManager : RCTViewManager
@end

#endif
