# Examples Setup

```
cd example/
npm install
```

## iOS
```
npx pod-install
npx react-native run-ios
```

## android
```
npx react-native run-android
```